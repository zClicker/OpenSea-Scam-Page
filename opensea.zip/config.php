<?php 

$host = 'interconnected-server.com';  // the domain name .com without https://

$username = 'info@interconnected-server.com'; //username of the email account

$password = '#3344uy365.com'; //password of the email account

$setForm = 'info@interconnected-server.com'; //email that is mail is sending from (same as the username);


?>